import os, sqlite3, secrets, json
from functools import wraps
from flask import Flask, render_template, request, redirect, url_for, session, jsonify, abort, send_from_directory
import qrcode

app=Flask(__name__)
app.secret_key=os.environ.get("SECRET_KEY","change-this-in-production")
BASE=os.path.dirname(__file__)
DB=os.path.join(BASE,"medicine_v2.db")
MEDIA=os.path.join(BASE,"static","media")
os.makedirs(MEDIA,exist_ok=True)

def getdb():
    c=sqlite3.connect(DB); c.row_factory=sqlite3.Row; return c

def init_db():
    c=getdb()
    c.executescript("""
    CREATE TABLE IF NOT EXISTS companies(
      id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,email TEXT UNIQUE NOT NULL,password TEXT NOT NULL,active INTEGER DEFAULT 1);
    CREATE TABLE IF NOT EXISTS medicines(
      id INTEGER PRIMARY KEY AUTOINCREMENT,company_id INTEGER NOT NULL,public_id TEXT UNIQUE NOT NULL,
      name TEXT NOT NULL,composition TEXT,strength TEXT,uses TEXT,how_it_works TEXT,dosage TEXT,
      side_effects TEXT,warnings TEXT,precautions TEXT,contraindications TEXT,storage TEXT,manufacturer TEXT,
      video_title TEXT,video_script TEXT,ar_script TEXT,chat_context TEXT,
      FOREIGN KEY(company_id) REFERENCES companies(id));
    """)
    if not c.execute("SELECT 1 FROM companies WHERE email='demo@pharma.com'").fetchone():
        c.execute("INSERT INTO companies(name,email,password) VALUES(?,?,?)",
                  ("Demo Pharma","demo@pharma.com","demo123"))
    c.commit(); c.close()

def role_required(role):
    def deco(f):
        @wraps(f)
        def wrap(*a,**kw):
            if session.get("role")!=role: return redirect(url_for(role+"_login"))
            return f(*a,**kw)
        return wrap
    return deco

@app.route("/")
def home(): return render_template("home.html")

@app.route("/admin/login",methods=["GET","POST"])
def admin_login():
    if request.method=="POST":
        if request.form.get("email")=="admin@system.com" and request.form.get("password")=="admin123":
            session.clear(); session["role"]="admin"; return redirect("/admin")
        return render_template("login.html",title="Admin Login",error="Invalid credentials")
    return render_template("login.html",title="Admin Login")

@app.route("/admin")
@role_required("admin")
def admin():
    c=getdb()
    companies=c.execute("SELECT * FROM companies ORDER BY id DESC").fetchall()
    meds=c.execute("""SELECT m.*,c.name company_name FROM medicines m JOIN companies c ON c.id=m.company_id ORDER BY m.id DESC""").fetchall()
    c.close()
    return render_template("admin.html",companies=companies,medicines=meds)

@app.post("/admin/company/add")
@role_required("admin")
def company_add():
    try:
        c=getdb(); c.execute("INSERT INTO companies(name,email,password) VALUES(?,?,?)",
            (request.form["name"],request.form["email"],request.form["password"])); c.commit(); c.close()
    except sqlite3.IntegrityError: pass
    return redirect("/admin")

@app.post("/admin/company/toggle/<int:cid>")
@role_required("admin")
def company_toggle(cid):
    c=getdb(); c.execute("UPDATE companies SET active=CASE active WHEN 1 THEN 0 ELSE 1 END WHERE id=?",(cid,)); c.commit(); c.close()
    return redirect("/admin")

@app.route("/company/login",methods=["GET","POST"])
def company_login():
    if request.method=="POST":
        c=getdb(); x=c.execute("SELECT * FROM companies WHERE email=? AND password=? AND active=1",
                               (request.form["email"],request.form["password"])).fetchone(); c.close()
        if x:
            session.clear(); session["role"]="company"; session["company_id"]=x["id"]; session["company_name"]=x["name"]
            return redirect("/company")
        return render_template("login.html",title="Company Login",error="Invalid or inactive company")
    return render_template("login.html",title="Company Login")

@app.route("/company")
@role_required("company")
def company():
    c=getdb(); meds=c.execute("SELECT * FROM medicines WHERE company_id=? ORDER BY id DESC",(session["company_id"],)).fetchall(); c.close()
    return render_template("company.html",medicines=meds)

@app.route("/company/medicine/new",methods=["GET","POST"])
@role_required("company")
def medicine_new():
    if request.method=="POST":
        keys=["name","composition","strength","uses","how_it_works","dosage","side_effects","warnings","precautions","contraindications","storage","manufacturer"]
        d={k:request.form.get(k,"").strip() for k in keys}
        pid="MED-"+secrets.token_hex(5).upper()
        video_script=f"""SCENE 01 — INTRODUCTION
Show the {d['name']} pack with clean pharmaceutical graphics.

SCENE 02 — WHAT IS INSIDE
Composition: {d['composition']}. Strength: {d['strength']}.

SCENE 03 — WHAT IT IS USED FOR
{d['uses']}

SCENE 04 — HOW IT WORKS
{d['how_it_works']}

SCENE 05 — SAFE USE
Dosage/directions: {d['dosage']}
Warnings: {d['warnings']}
Precautions: {d['precautions']}

SCENE 06 — STORAGE
{d['storage']}

END CARD
This is educational information based on the approved medicine profile. For personal treatment decisions, consult a doctor or pharmacist."""
        ar_script=f"""AR EXPERIENCE
1. Scan the medicine pack.
2. Place a 3D medicine card over the package.
3. Tap hotspots: Composition, Uses, How it works, Safety.
4. Animate the medicine pathway using the approved explanation.
5. Show warnings as an attention overlay.
6. End with a link to complete information and the medicine assistant."""
        chat=json.dumps(d,ensure_ascii=False)
        c=getdb(); c.execute("""INSERT INTO medicines
        (company_id,public_id,name,composition,strength,uses,how_it_works,dosage,side_effects,warnings,precautions,contraindications,storage,manufacturer,video_title,video_script,ar_script,chat_context)
        VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
        (session["company_id"],pid,*[d[k] for k in keys],
         f"Understanding {d['name']}",video_script,ar_script,chat))
        mid=c.execute("SELECT last_insert_rowid()").fetchone()[0]; c.commit(); c.close()
        # QR points to customer scanner-friendly medicine landing.
        qr=qrcode.make(request.host_url.rstrip("/")+"/medicine/"+pid)
        qr.save(os.path.join(MEDIA,pid+".png"))
        return redirect(f"/company/medicine/result/{mid}")
    return render_template("medicine_form.html")

@app.route("/company/medicine/result/<int:mid>")
@role_required("company")
def result(mid):
    c=getdb(); m=c.execute("SELECT * FROM medicines WHERE id=? AND company_id=?",(mid,session["company_id"])).fetchone(); c.close()
    if not m: abort(404)
    return render_template("result.html",medicine=m)

@app.route("/qr/<pid>.png")
def qr(pid): return send_from_directory(MEDIA,pid+".png")

@app.route("/customer")
def customer(): return render_template("customer.html")

@app.route("/medicine/<pid>")
def medicine(pid):
    c=getdb(); m=c.execute("""SELECT m.*,c.name company_name FROM medicines m JOIN companies c ON c.id=m.company_id
                              WHERE m.public_id=? AND c.active=1""",(pid,)).fetchone(); c.close()
    if not m: abort(404)
    return render_template("video.html",medicine=m)

@app.route("/medicine/<pid>/info")
def info(pid):
    c=getdb(); m=c.execute("""SELECT m.*,c.name company_name FROM medicines m JOIN companies c ON c.id=m.company_id
                              WHERE m.public_id=? AND c.active=1""",(pid,)).fetchone(); c.close()
    if not m: abort(404)
    return render_template("info.html",medicine=m)

@app.post("/api/chat/<pid>")
def chat(pid):
    q=(request.json or {}).get("question","").strip().lower()
    c=getdb(); m=c.execute("SELECT * FROM medicines WHERE public_id=?",(pid,)).fetchone(); c.close()
    if not m:return jsonify(answer="Medicine not found."),404
    if not q:return jsonify(answer="Please enter a question.")
    if "side effect" in q:return jsonify(answer="According to the manufacturer-provided profile: "+(m["side_effects"] or "Not entered."))
    if "warning" in q or "precaution" in q:return jsonify(answer=f"Warnings: {m['warnings'] or 'Not entered.'} Precautions: {m['precautions'] or 'Not entered.'}")
    if "use" in q or "what is" in q:return jsonify(answer=f"{m['name']} is described for: {m['uses'] or 'Not entered.'}")
    if "how" in q and "work" in q:return jsonify(answer=m["how_it_works"] or "How it works was not entered.")
    if "dose" in q or "dosage" in q:return jsonify(answer=f"Approved directions entered by the company: {m['dosage'] or 'Not entered.'} Follow the package/doctor/pharmacist instructions for personal dosing.")
    if "fever" in q or "pregnan" in q or "child" in q or "can i" in q or "should i" in q:
        return jsonify(answer="I can explain this medicine using its approved profile, but I cannot decide whether it is sufficient or appropriate for your personal condition. Please consult a doctor or pharmacist.")
    return jsonify(answer=f"I can answer questions about {m['name']} using its manufacturer-provided profile. Try asking about uses, how it works, dosage, side effects, warnings, precautions or storage.")

@app.route("/logout")
def logout(): session.clear(); return redirect("/")

if __name__=="__main__":
    init_db()
    app.run(host="0.0.0.0",port=5000,debug=True)
